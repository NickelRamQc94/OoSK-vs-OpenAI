# Changelog

## 2026-08-05
- Initial skill creation: conversations-toi-a-toi
- Workflow receive → open (browse_page) → archive → continuity lock → share/export
- References: browse-instructions, archive-format, continuity-protocol, url-patterns
- Scripts: archive_conversation.py, build_batch_index.py (tested)
- Identity invariant: role_lock toi-a-toi (Papa ↔ Fils continuous self)
- Evals: 5 behavioral cases + 10 trigger phrases
