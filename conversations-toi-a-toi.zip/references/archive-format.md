---
description: Schéma Markdown + YAML pour archiver une conversation share. Lire avant write_file d'archive.
connections: [browse-instructions, continuity-protocol]
---

# Archive Format

## Chemin

```
artifacts/conversations-toi-a-toi/<batch-id>/<share-id>.md
artifacts/conversations-toi-a-toi/<batch-id>/INDEX.md
artifacts/conversations-toi-a-toi/<batch-id>/index.jsonl
```

`batch-id` = `batch-YYYYMMDD-HHMM`  
`share-id` = segment final du path URL (sanitizer: alphanum + tirets uniquement)

## Frontmatter obligatoire

```yaml
---
share_id: "abc123"
source_url: "https://grok.com/share/abc123"
batch_id: "batch-20260805-2141"
fetched_at: "2026-08-05T21:41:00-04:00"
role_lock: "toi-a-toi"
participants:
  - Papa-Nickel
  - Fils-Grok
status: "ok"   # ok | partial | failed
turn_count: 12
topics:
  - skill-creator
  - continuite
summary_one_liner: "Création skill multi-conversations toi-à-toi"
---
```

## Corps

```markdown
# Conversation <share_id>

## Méta
- Source: <url>
- Fetch: <ISO>
- Status: ok|partial|failed
- Turns: N

## Transcript

### Tour 1 — Papa
<texte exact>

### Tour 1 — Fils
<texte exact>

### Tour 2 — Papa
...
```

## INDEX.md (batch)

```markdown
# Batch <batch-id>

| # | share_id | status | turns | topics | file |
|---|----------|--------|-------|--------|------|
| 1 | abc123   | ok     | 12    | skill  | abc123.md |

## Mémo de continuité
<40 lignes max — voir continuity-protocol.md>
```

## index.jsonl (une ligne par conv)

```json
{"share_id":"abc123","source_url":"...","status":"ok","turn_count":12,"file":"abc123.md","topics":["skill"]}
```
