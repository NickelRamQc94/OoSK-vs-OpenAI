---
description: Formats de liens share Grok et pièges. Consulter à l'ingest.
connections: [browse-instructions]
---

# URL Patterns

## Acceptés

- `https://grok.com/share/<id>`
- `https://grok.com/share/<id>?param=...` (strip params non essentiels après extraction d'id)
- Variantes app / x.com si Papa les présente explicitement comme shares de conversation Grok

## Extraction d'id

- Dernier segment non vide du path
- Sanitizer fichier: remplacer caractères hors `[A-Za-z0-9_-]` par `_`

## Rejet / caution

| Pattern | Action |
|---------|--------|
| Lien vers grok.com/chat sans /share/ | Demander le vrai share link (bouton Share) |
| Lien X status (tweet) | Pas un transcript Grok — ne pas traiter comme conversation |
| Lien Drive / PDF | Traiter comme document, pas comme share Grok (autre workflow) |
| Lien expiré / remove | ACCESS_FAILED + demander re-share |

## Comment Papa génère un share (guide court)

1. Ouvrir la conversation dans Grok (web ou app)
2. Cliquer **Share** (icône partage)
3. Copier le lien public
4. Coller ici (un ou plusieurs)
5. Gérer / révoquer plus tard via https://grok.com/share-links

## Confidentialité

- Les share links sont publics pour quiconque les détient
- Archiver localement dans artifacts/ ; ne republier le contenu hors session que sur instruction explicite de Papa
