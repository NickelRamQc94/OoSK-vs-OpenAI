---
description: Template d'instructions pour browse_page sur un share link Grok. Lire avant chaque open.
connections: [archive-format, url-patterns]
---

# Browse Instructions — Share Link Grok

## Template standard (copier tel quel dans `instructions`)

```
Extract the FULL shared Grok conversation transcript from this page.

Return structured content:
1) Title or first user message summary (1 line)
2) Share id if visible in URL or page
3) Complete chronological list of turns:
   - Role: User or Grok/Assistant (map User→Papa, Grok→Fils when relevant)
   - Full text of each message (do not summarize away technical content, code, equations, or names)
4) Any metadata: date, model name, attachments/images counts if shown
5) If the page requires login, is empty, 404, or blocked: state that clearly as ACCESS_FAILED with the exact error signal seen

Rules:
- Prefer verbatim quotes over paraphrase for user and assistant messages
- Preserve code blocks, lists, and headings
- If the page is truncated, extract everything visible and mark TRUNCATED
- Do not invent turns
- Output in clear Markdown with ### Tour N — User / ### Tour N — Grok headings
```

## Template agressif (retry)

```
This is a public Grok conversation share page. Ignore chrome, nav, footers, cookie banners.
Scrape every chat bubble / message block in order from top to bottom.
For each message output:
ROLE: user|assistant
TEXT: <full text>
If nothing readable, reply only: ACCESS_FAILED reason=<login|empty|404|js-wall|other>
```

## Post-fetch checks

- Si `ACCESS_FAILED` → ne pas archiver comme ok
- Si < 2 tours et page non vide → marquer `partial`
- Si code / maths présents → vérifier qu'ils n'ont pas été omis dans le résumé outil; re-browse avec focus si doute
