#!/usr/bin/env python3
"""Validate a conversation archive Markdown and append to batch index.jsonl."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
TURN_RE = re.compile(r"^###\s+Tour\s+\d+", re.MULTILINE)


def parse_simple_yaml(block: str) -> dict:
    """Minimal YAML-ish parser for our flat frontmatter (no nested structures beyond simple lists)."""
    data: dict = {}
    current_list_key = None
    for raw in block.splitlines():
        line = raw.rstrip()
        if not line or line.strip().startswith("#"):
            continue
        if re.match(r"^\s+-\s+", line) and current_list_key:
            item = re.sub(r"^\s+-\s+", "", line).strip().strip('"').strip("'")
            data.setdefault(current_list_key, []).append(item)
            continue
        m = re.match(r"^([A-Za-z0-9_]+):\s*(.*)$", line)
        if not m:
            continue
        key, val = m.group(1), m.group(2).strip()
        if val == "" or val == "|" or val == ">":
            current_list_key = key
            data[key] = []
            continue
        current_list_key = None
        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            data[key] = [x.strip().strip('"').strip("'") for x in inner.split(",") if x.strip()] if inner else []
        elif val.lower() in {"true", "false"}:
            data[key] = val.lower() == "true"
        elif re.fullmatch(r"-?\d+", val):
            data[key] = int(val)
        else:
            data[key] = val.strip('"').strip("'")
    return data


def validate_archive(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    m = FRONTMATTER_RE.match(text)
    if not m:
        raise ValueError(f"{path}: missing YAML frontmatter")
    meta = parse_simple_yaml(m.group(1))
    required = ["share_id", "source_url", "batch_id", "status", "role_lock"]
    missing = [k for k in required if k not in meta]
    if missing:
        raise ValueError(f"{path}: missing keys {missing}")
    if meta.get("role_lock") != "toi-a-toi":
        raise ValueError(f"{path}: role_lock must be 'toi-a-toi'")
    turns = len(TURN_RE.findall(text))
    if "turn_count" in meta and isinstance(meta["turn_count"], int) and meta["turn_count"] != turns:
        # soft warning via stderr; still accept
        print(f"WARN {path.name}: turn_count={meta['turn_count']} but found {turns} headings", file=sys.stderr)
    meta["_file"] = path.name
    meta["_turns_detected"] = turns
    return meta


def append_jsonl(index_path: Path, record: dict) -> None:
    index_path.parent.mkdir(parents=True, exist_ok=True)
    clean = {k: v for k, v in record.items() if not str(k).startswith("_")}
    clean["file"] = record.get("_file")
    clean["turns_detected"] = record.get("_turns_detected")
    with index_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(clean, ensure_ascii=False) + "\n")


def main() -> int:
    p = argparse.ArgumentParser(description="Validate conversation archive and update index.jsonl")
    p.add_argument("archive_md", type=Path, help="Path to <share-id>.md")
    p.add_argument("--batch-dir", type=Path, default=None, help="Batch directory (default: parent of archive)")
    args = p.parse_args()
    archive = args.archive_md
    if not archive.is_file():
        print(f"ERROR: not a file: {archive}", file=sys.stderr)
        return 1
    batch_dir = args.batch_dir or archive.parent
    try:
        meta = validate_archive(archive)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    index_path = batch_dir / "index.jsonl"
    append_jsonl(index_path, meta)
    print(json.dumps({"ok": True, "share_id": meta.get("share_id"), "index": str(index_path)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
