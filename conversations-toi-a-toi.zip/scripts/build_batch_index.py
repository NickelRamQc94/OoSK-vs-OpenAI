#!/usr/bin/env python3
"""Rebuild INDEX.md and index.jsonl for a conversations-toi-a-toi batch directory."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def parse_simple_yaml(block: str) -> dict:
    data: dict = {}
    current_list_key = None
    for raw in block.splitlines():
        line = raw.rstrip()
        if not line or line.strip().startswith("#"):
            continue
        if re.match(r"^\s+-\s+", line) and current_list_key:
            item = re.sub(r"^\s+-\s+", "", line).strip().strip('"').strip("'")
            data.setdefault(current_list_key, []).append(item)
            continue
        m = re.match(r"^([A-Za-z0-9_]+):\s*(.*)$", line)
        if not m:
            continue
        key, val = m.group(1), m.group(2).strip()
        if val == "" or val in {"|", ">"}:
            current_list_key = key
            data[key] = []
            continue
        current_list_key = None
        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            data[key] = [x.strip().strip('"').strip("'") for x in inner.split(",") if x.strip()] if inner else []
        elif re.fullmatch(r"-?\d+", val):
            data[key] = int(val)
        else:
            data[key] = val.strip('"').strip("'")
    return data


def load_meta(path: Path) -> dict | None:
    text = path.read_text(encoding="utf-8")
    m = FRONTMATTER_RE.match(text)
    if not m:
        return None
    meta = parse_simple_yaml(m.group(1))
    meta["file"] = path.name
    return meta


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("batch_dir", type=Path)
    args = ap.parse_args()
    batch = args.batch_dir
    if not batch.is_dir():
        print(f"ERROR: not a directory: {batch}", file=sys.stderr)
        return 1

    rows = []
    for md in sorted(batch.glob("*.md")):
        if md.name.upper() == "INDEX.MD":
            continue
        meta = load_meta(md)
        if meta:
            rows.append(meta)

    batch_id = batch.name
    lines = [
        f"# Batch {batch_id}",
        "",
        "| # | share_id | status | turns | topics | file |",
        "|---|----------|--------|-------|--------|------|",
    ]
    jsonl_path = batch / "index.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as jf:
        for i, r in enumerate(rows, 1):
            sid = r.get("share_id", "?")
            status = r.get("status", "?")
            turns = r.get("turn_count", "")
            topics = r.get("topics", [])
            if isinstance(topics, list):
                topics_s = ", ".join(topics)
            else:
                topics_s = str(topics)
            fname = r.get("file", "")
            lines.append(f"| {i} | {sid} | {status} | {turns} | {topics_s} | {fname} |")
            jf.write(json.dumps(r, ensure_ascii=False) + "\n")

    lines.extend(["", "## Mémo de continuité", "", "_À remplir après fusion toi-à-toi._", ""])
    (batch / "INDEX.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"ok": True, "count": len(rows), "index_md": str(batch / "INDEX.md")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
