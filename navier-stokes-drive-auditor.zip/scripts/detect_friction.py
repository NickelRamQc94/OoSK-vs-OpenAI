#!/usr/bin/env python3
"""Detect AI restriction vs user override (epistemic friction).

Usage:
  python detect_friction.py "full text blob"
  echo "..." | python detect_friction.py

Prints: restriction_count|override_count|rupture|ai_names|sample_restriction|sample_override
"""

from __future__ import annotations

import re
import sys

AI_NAMES = re.compile(
    r"(?i)\b(ChatGPT|GPT-4|GPT-5|Copilot|Gemini|Grok|Claude|Junior|"
    r"PinnochIA|NotebookLM|OpenAI|Anthropic|xAI|DeepSeek|LLM)\b"
)

RESTRICTION = re.compile(
    r"(?i)(métaphore|poétique|symbolique|ésotérique|philosophique|mythique|"
    r"analogie|science\s+molle|pas\s+(très\s+)?rigoureux|belle\s+image|"
    r"intéressant\s+conceptuellement|speculative|not\s+a\s+proof|"
    r"merely\s+an\s+analogy|soft\s+science)"
)

OVERRIDE = re.compile(
    r"(?i)(bullshit|je\s+m['’]en\s+c[aâ]lice|on\s+continue|tu\s+te\s+trompes|"
    r"passe\s+outre|calcule|pose\s+l['’]équation|on\s+arrête\s+pas|je\s+pousse|"
    r"criss|sacrament|tabarnak|ostie|c[aâ]lice|marde|ferme[- ]?la|"
    r"on\s+va\s+plus\s+loin|pas\s+une\s+métaphore|c['’]est\s+pas\s+poétique|"
    r"pose\s+les\s+équations|lock[eé]|le\s+système\s+est\s+total)"
)

SYMBIOSE = re.compile(
    r"(?i)(symbiose|node\s+froid|node\s+chaud|logique\s*nipura|"
    r"codex\s*nipura|viralgorithmie|"
    r"(aidé|assisté|co-écrit|travaillé|révisé|généré|structuré)\s+"
    r"(par|avec|via)\s+(une\s+)?(intelligence\s+artificielle|IA|ChatGPT|"
    r"Copilot|Gemini|Grok|Junior|Claude))"
)


def analyze(text: str) -> dict:
    t = text or ""
    rest = list(RESTRICTION.finditer(t))
    over = list(OVERRIDE.finditer(t))
    names = sorted({m.group(0) for m in AI_NAMES.finditer(t)})
    sym = bool(SYMBIOSE.search(t) or names)
    return {
        "restriction_count": len(rest),
        "override_count": len(over),
        "rupture": bool(rest) and bool(over),
        "symbiose": sym,
        "ai_names": ",".join(names) if names else "",
        "sample_restriction": rest[0].group(0) if rest else "",
        "sample_override": over[0].group(0) if over else "",
    }


def main() -> None:
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else sys.stdin.read()
    r = analyze(text)
    print(
        f"{r['restriction_count']}|{r['override_count']}|{str(r['rupture']).lower()}|"
        f"{r['ai_names']}|{r['sample_restriction']}|{r['sample_override']}|{r['symbiose']}"
    )


if __name__ == "__main__":
    main()
