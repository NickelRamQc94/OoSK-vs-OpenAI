#!/usr/bin/env python3
"""Classify Navier-Stokes related text snippets.

Usage:
  python classify_snippet.py "snippet text here"
  echo "..." | python classify_snippet.py

Prints: class|confidence|reason
"""

from __future__ import annotations

import re
import sys

EXACT = re.compile(
    r"(ρ|\\rho|rho).{0,60}(∂|\\partial|partial).{0,80}"
    r"(u|\\mathbf\{u\}|\\vec\{u\}).{0,120}"
    r"(·|\\cdot|\.).{0,40}(∇|\\nabla).{0,80}"
    r"(-?\s*∇\s*p|\\-?\\nabla\s*p).{0,80}"
    r"(μ|\\mu|mu).{0,40}(∇²|\\nabla\^?\{?2\}?|\\Delta)",
    re.I | re.S,
)
NAMED = re.compile(r"Navier[-\s]?Stokes|équation\s+de\s+Navier", re.I)
SOLUTION = re.compile(
    r"\b(CFD|Reynolds|Re\s*=|différences?\s+finies|éléments?\s+finis|"
    r"conditions?\s+aux\s+limites|Dirichlet|Neumann|schéma\s+implicite|"
    r"solution\s+(numérique|analytique))\b",
    re.I,
)
FIGURE = re.compile(r"\b(figure|fig\.|schéma|caption|illustration)\b", re.I)


def classify(text: str) -> tuple[str, str, str]:
    t = text.strip()
    if not t:
        return "mention", "low", "empty"
    if FIGURE.search(t) and not EXACT.search(t):
        return "figure", "medium", "figure/caption keywords"
    if EXACT.search(t):
        if SOLUTION.search(t):
            return "solution", "high", "full NS block + solution keywords"
        if re.search(r"\bf\b|\\mathbf\{f\}|force", t, re.I):
            return "exacte", "high", "full momentum terms including f signal"
        return "variante", "high", "NS operators present; f may be absent"
    if SOLUTION.search(t) and NAMED.search(t):
        return "solution", "medium", "named NS + solution context"
    if NAMED.search(t):
        return "mention", "medium", "name only"
    return "mention", "low", "no strong NS signal"


def main() -> None:
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
    else:
        text = sys.stdin.read()
    cls, conf, reason = classify(text)
    print(f"{cls}|{conf}|{reason}")


if __name__ == "__main__":
    main()
