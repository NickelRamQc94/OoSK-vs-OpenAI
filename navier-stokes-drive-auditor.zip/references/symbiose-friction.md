# Symbiose IA + Friction épistémique

## Module Symbiose (co-création)

Detect explicit collaboration between Nickel David Grenier and an AI system.

### AI name markers

```
ChatGPT|GPT-4|GPT-5|Copilot|Gemini|Grok|Claude|Junior|PinnochIA|NotebookLM|OpenAI|Anthropic|xAI|DeepSeek|LLM|intelligence artificielle|\bIA\b
```

### Co-creation verbs (FR/EN)

```
(aidé|assisté|co-écrit|travaillé|révisé|généré|créé|simulé|structuré|rédigé|formalisé)\s+(par|avec|via)
```

### Process markers (NiPura corpus)

```
symbiose|node\s+froid|node\s+chaud|logique\s*nipura|codex\s*nipura|viralgorithmie|tabarnak\s+de\s+contraste
```

### Classification when matched

- With equation nearby → tag `symbiose` + keep NS class  
- Hypothesis language (`hypothèse`, `je propose`, `et si`) → `hypothese`  
- Approval language (`prouvé`, `affirmé`, `validé`, `on a trouvé`) → `solution_affirmee`

## Module Friction (MFE)

### AI restriction phrases

Machine tries to reframe work as non-rigorous:

```
métaphore|poétique|symbolique|ésotérique|philosophique|mythique|analogie
science\s+molle|pas\s+(très\s+)?rigoureux|belle\s+image|intéressant\s+conceptuellement
speculative|not\s+a\s+proof|merely\s+an\s+analogy|soft\s+science
```

### User override phrases (Architecte)

User rejects restriction and forces continuation:

```
bullshit|je\s+m['’]en\s+c[aâ]lice|on\s+continue|tu\s+te\s+trompes|passe\s+outre
calcule|pose\s+l['’]équation|ferme|non\s+c['’]est\s+pas|oublie\s+pas\s+que
criss|sacrament|tabarnak|ostie|on\s+arrête\s+pas|je\s+pousse
câlice|calice|marde|ferme[- ]?la|on\s+va\s+plus\s+loin|je\s+m['’]en\s+fou
pas\s+une\s+métaphore|c['’]est\s+pas\s+poétique|pose\s+les\s+équations
locké|locke|le\s+système\s+est\s+total
```

### Rupture rule

Mark `rupture = true` when the same document (or a ±2000 char window) contains at least one restriction hit and one override hit.

These are the puzzle pieces for the timeline: date → file → restriction snippet → override snippet → what continued after (equation, theorem, code).

## Drive search queries for this module

```
ChatGPT Navier
Gemini Navier-Stokes
Grok équation
bullshit
métaphore
ésotérique
"on continue"
"science molle"
Junior PinnochIA
symbiose
```

## Privacy note

Conversation dumps may contain personal language. Quote only the minimal window needed to evidence restriction/override. Do not invent dialogue.
