# Search patterns — Navier-Stokes Drive Auditor

## Canonical equation

$$\rho \left( \frac{\partial \mathbf{u}}{\partial t} + \mathbf{u} \cdot \nabla \mathbf{u} \right) = -\nabla p + \mu \nabla^{2}\mathbf{u} + \mathbf{f}$$

Symbol glossary:

| Symbol | Meaning |
|--------|---------|
| ρ / `\rho` | Masse volumique |
| u / `\mathbf{u}` / `\vec{u}` | Vecteur vitesse |
| ∂ / `\partial` | Dérivée partielle |
| t | Temps |
| · / `\cdot` | Produit scalaire |
| ∇ / `\nabla` | Nabla (gradient / opérateurs) |
| p | Pression |
| μ / `\mu` | Viscosité dynamique |
| ∇² / `\nabla^{2}` / `\Delta` | Laplacien |
| f / `\mathbf{f}` | Forces externes |

## Google Drive query strings

Run several searches; Drive full-text works best on Google Docs.

```
Navier-Stokes
Navier Stokes
\partial_t \mathbf{u}
\mathbf{u}\cdot\nabla
\nabla^{2}\mathbf{u}
∂u/∂t
ρ ( ∂u/∂t
GrenierNv-Stokes
NKL.D Grenier
texte 4
texte 36
texte 5
texte 90
NickelEllOS
```

Useful filters via tool args (not raw Drive bar):

- `mime_type_filter`: `application/vnd.google-apps.document` or `application/pdf`
- `title_only: true` when hunting exact document titles
- `exact_name` for priority targets

## Regex tiers (Python `re`, flags `re.I | re.S`)

### 1. Permissive (candidates)

```
(ρ|\\rho|rho).{0,40}(∂|\\partial|partial).{0,40}(u|\\mathbf\{u\}|\\vec\{u\}).{0,80}(u\s*[·\.]\\s*∇|\\mathbf\{u\}\\cdot\\nabla|u\\s*·\\s*∇).{0,80}(-∇\s*p|\\-\\nabla\s*p|-\\nabla\s*p).{0,80}(μ|\\mu|mu).{0,40}(∇²|\\nabla\^?\{?2\}?|\\Delta|laplacian)
```

### 2. Unicode / plain text

```
ρ\s*\(?\s*(∂u/∂t|∂\s*u\s*/∂\s*t|∂_t\s*u)\s*\+\s*u\s*[·\.]\s*∇\s*u\s*\)?\s*=\s*-?\s*∇\s*p\s*\+\s*μ\s*∇²\s*u(?:\s*\+\s*f)?
```

### 3. LaTeX

```
\\rho\s*\(?\s*\\partial_t\s*\\mathbf\{u\}\s*\+.*?\\mathbf\{u\}\s*\\cdot\s*\\nabla\s*\\mathbf\{u\}\s*\)?\s*=\s*-\\nabla\s*p\s*\+\s*\\mu\s*\\nabla\^?\{?2\}?\\mathbf\{u\}(?:\s*\+\s*\\mathbf\{f\})?
```

### 4. Named form (catch textual mentions)

```
(Navier[-\s]?Stokes|équation\s+de\s+Navier|NS\s+incompressible|momentum\s+equation)
```

## Matching policy

1. Run permissive → collect candidates.
2. Re-score with Unicode + LaTeX tiers.
3. Keep snippet ≤ 800 characters, collapse whitespace to single spaces for CSV.
4. If only the name “Navier-Stokes” appears without operators, class = `mention`.
