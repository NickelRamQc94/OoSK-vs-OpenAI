# Classification rules v2

## NS classes (pick one primary)

| Class | Criteria |
|-------|----------|
| `exacte` | ρ, unsteady ∂u/∂t, convection u·∇u, −∇p, viscous term, preferably f in one block |
| `variante` | Same family with missing/extra terms (no f, Stokes, Euler, compressible, vorticity, NiPura, MHD, asymptotic 1/x) |
| `solution` | CFD, finite differences/elements, BCs, Reynolds, mild/weak/classical solution theory, BKM |
| `mention` | Named reference without operators |
| `figure` | Caption / schema only |
| `annexe` | Deployment, tooling, script packaging the equation |

## Orthogonal tags (stackable)

| Tag | Criteria |
|-----|----------|
| `symbiose` | AI name + co-creation context |
| `hypothese` | User hypothesis stated in dialogue or note |
| `solution_affirmee` | Claim of found/approved solution step |
| `restriction_ia` | Soft/poetic/philosophical downplay by AI |
| `override_user` | User rejects and orders hard continuation |
| `rupture` | restriction_ia and override_user co-located |

## False positives

- Pure continuity ∇·u = 0 alone
- Heat equation ∇²T only
- Chemistry density without velocity field
- Casual IA without model names
- Swear words outside a restriction-override pair

## Confidence

- High: full equation block or clear restriction+override pair with quotes
- Medium: named NS + AI name in same file
- Low: name-only mention

## Timeline rule

Sort rupture and solution_affirmee events by modified_time ascending. Present as ordered puzzle pieces.
