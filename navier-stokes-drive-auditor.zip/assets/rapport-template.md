# Occurrences de l’équation de Navier-Stokes et empreinte de Symbiose

**Date d’audit :** YYYY-MM-DD  
**Skill :** navier-stokes-drive-auditor v2.0.0  
**Architecte :** Nickel David Grenier  

**Équation cible :**

$$\rho \left( \frac{\partial \mathbf{u}}{\partial t} + \mathbf{u} \cdot \nabla \mathbf{u} \right) = -\nabla p + \mu \nabla^{2}\mathbf{u} + \mathbf{f}$$

## Résumé exécutif

- Occurrences NS détectées : X  
- Fichiers distincts : Y  
- Tags symbiose : Z  
- Ruptures paradigmatiques (restriction IA + override user) : R  
- Types : Google Docs ; PDF ; scripts ; exports de conversation  

## 1. Tableau récapitulatif Navier-Stokes

| Fichier | Date modif. | Type | Classe | Contexte | Solution / Remarque |
|---------|-------------|------|--------|----------|---------------------|
| … | … | … | … | … | … |

## 2. Empreinte de la Symbiose artificielle

Documents où une IA est nommée comme co-outil de formalisation, simulation ou rédaction.

| Fichier | IA identifiée | Type de collaboration | Extrait / contexte |
|---------|---------------|----------------------|--------------------|
| … | … | … | … |

## 3. Friction épistémique et timeline des ruptures

Moments où l’IA tente un cadrage soft (métaphore, poétique, science molle) et où l’utilisateur force la poursuite formelle.

| Date | Fichier | Restriction IA (snippet) | Override user (snippet) | Suite (équation / preuve / code) |
|------|---------|--------------------------|-------------------------|----------------------------------|
| … | … | … | … | … |

Chaque ligne est une pièce de casse-tête chronologique de la co-création.

## 4. Détails par occurrence NS

### Fichier : NOM

- **file_id :** …  
- **Classe / tags :** …  
- **Snippet :** …  
- **Contexte :** …  
- **Commentaires :** …  

## Annexes

- Méthode : google_drive_search + google_drive_read_file (+ download PDF)  
- Patterns : references/search-patterns.md, references/symbiose-friction.md  
- Exports : navier_occurrences.csv, audit_symbiose_friction.csv  
