---
name: navier-stokes-drive-auditor
description: Audit Navier-Stokes occurrences plus AI co-creation footprints and epistemic friction in Google Drive archives. Use for rapport Navier-Stokes, symbiose IA, friction epistemique, bullshit override, NKL.D GrenierNv-Stokes, texte 4/5/36/90, ChatGPT Gemini Grok Junior pushback, puzzle timeline of hypotheses and solutions.
metadata:
  version: "2.0.0"
  author: Nickel D. Grenier
  type: workflow
---

# Navier-Stokes Drive Auditor v2

Audit three layers in the user Google Drive archives:

1. **Navier-Stokes physics** — equation occurrences and variants  
2. **Symbiose IA** — explicit co-creation with ChatGPT, Gemini, Grok, Copilot, Junior, Claude, PinnochIA  
3. **Friction épistémique** — moments where an AI frames the work as soft/poetic/philosophical and the user (Nickel David Grenier) overrides and continues

Canonical equation:

$$\rho \left( \frac{\partial \mathbf{u}}{\partial t} + \mathbf{u} \cdot \nabla \mathbf{u} \right) = -\nabla p + \mu \nabla^{2}\mathbf{u} + \mathbf{f}$$

## When activated

1. Prefer connected Google Drive tools over local OAuth scripts.
2. Search priority targets first, then broaden.
3. Run all three pattern modules on extracted text.
4. Emit dual Markdown report + dual CSV under `/home/workdir/artifacts/`.

## Priority targets

| Priority | Name / pattern |
|----------|----------------|
| 1 | `NKL.D GrenierNv-Stokes` / `GrenierNv-Stokes` |
| 2 | `Si tu veux aller au niveau "vrai papier scientifique"` |
| 3 | `Setup + Abstract` / `Copie de - Setup` |
| 4 | `texte 4`, `texte 5`, `texte 36`, `texte 90` |
| 5 | `Script de Déploiement Universel` / `NickelEllOS` / `NvickelìOs` |
| 6 | `Cumule Ni. D` |
| 7 | Conversation exports, chat archives, share links pasted into Docs |
| 8 | `Horodatage Équation Navier-Stokes`, `Maths IA`, polycopiés NS |

## Workflow

### Step 1 — Index

- `google_drive_search` on each priority name and on equation fragments.
- Also search symbiosis markers: `ChatGPT`, `Gemini`, `Grok`, `Copilot`, `Junior`, `PinnochIA`, `symbiose`, `Node Froid`.
- Also search friction markers: `bullshit`, `métaphore`, `ésotérique`, `science molle`, `on continue`.
- Collect `file_id`, `name`, `mime_type`, `modified_time`, `web_view_link`.

### Step 2 — Extract

- Readable Workspace files: `include_content: true` or `google_drive_read_file`.
- PDFs: `google_drive_download_artifact` then extract text (pdf skill). Note OCR limits for scans.
- Large files: page/line windows; re-read sections that match markers.

### Step 3 — Match three modules

Patterns live in `references/search-patterns.md` and `references/symbiose-friction.md`.

1. **NS** — permissive → unicode → latex → named  
2. **Symbiose** — AI name + co-creation verbs + NiPura process markers  
3. **Friction** — AI restriction phrases + user override phrases; flag **rupture** when both appear in the same document or nearby windows

Record snippet ≤800 chars, module, approximate section, date if available.

### Step 4 — Classify

NS classes (one primary per NS hit):

| Class | Meaning |
|-------|---------|
| `exacte` | Full momentum form with main terms |
| `variante` | Same family with altered terms (NiPura, MHD, 1/x, no f, etc.) |
| `solution` | Analytical/numerical solution, BCs, CFD, regularity theorem |
| `mention` | Name-only or bibliography |
| `figure` | Caption / schema |
| `annexe` | Deployment script, tooling |

Symbiose / friction tags (orthogonal, can stack):

| Tag | Meaning |
|-----|---------|
| `symbiose` | Explicit AI co-writing or tool use |
| `hypothese` | User states a hypothesis with or against an AI |
| `solution_affirmee` | Claim that a solution step was found or approved |
| `restriction_ia` | AI downplays rigor (poetic, soft science, metaphor) |
| `override_user` | User rejects restriction and orders continuation |
| `rupture` | Same file/window has restriction_ia + override_user |

Treat conversation archives as first-class evidence. Prefer chronological ordering of rupture events (puzzle-piece timeline).

### Step 5 — Export

Write:

1. `navier_occurrences.csv` — NS rows  
   `file_name,file_id,modified_time,mime_type,class,pattern_tier,snippet,web_view_link`
2. `audit_symbiose_friction.csv` — symbiosis/friction rows  
   `file_name,file_id,modified_time,ai_named,symbiose_hits,restriction_hits,override_hits,rupture,snippet,web_view_link`
3. Markdown report from `assets/rapport-template.md` with three sections:  
   - Occurrences NS  
   - Empreinte de la Symbiose IA  
   - Friction épistémique et timeline des ruptures  

Optional Drive upload only if the user asks.

### Step 6 — Verify

- No invented quotes. Only tool-returned text.
- Drop pure chemistry ρ/μ noise and Euler-only when user asked for full NS.
- State unreadable PDFs and truncated conversation dumps clearly.

## Tool mapping

| Action | Tool |
|--------|------|
| Search | `google_drive_search` |
| Read | `google_drive_read_file` or `include_content` |
| Download PDF | `google_drive_download_artifact` |
| List folder | `google_drive_list_folder` |
| Upload | `google_drive_upload_artifact` |

## Output language

French by default. Equations in KaTeX. CSV headers English snake_case.

## Resources

- `references/search-patterns.md` — NS regex and Drive queries  
- `references/symbiose-friction.md` — AI signature and friction patterns  
- `references/classification.md` — class and tag rules  
- `assets/rapport-template.md` — full report skeleton v2  
- `scripts/classify_snippet.py` — NS snippet classifier  
- `scripts/detect_friction.py` — restriction / override / rupture helper  
