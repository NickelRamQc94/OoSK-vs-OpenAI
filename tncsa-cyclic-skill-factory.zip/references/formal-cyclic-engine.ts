// ============================================================
// FORMAL CYCLIC ENGINE — TNCSA v2.0
// Reference implementation for tncsa-cyclic-skill-factory
// Used by AGENT_11_POLYGLOTTE in RING-1 mode
// ============================================================

export interface TNCSAConfig {
  N: number;
  seuilGoldni: number;
  epsilonStar: number;
  lambda: number;
}

export interface Complex {
  re: number;
  im: number;
  add(other: Complex): Complex;
  sub(other: Complex): Complex;
  mul(other: Complex): Complex;
  div(scalar: number): Complex;
  norm2(): number;
  conjugate(): Complex;
}

export class ComplexImpl implements Complex {
  constructor(public re: number, public im: number = 0) {}

  add(other: Complex): Complex {
    return new ComplexImpl(this.re + other.re, this.im + other.im);
  }

  sub(other: Complex): Complex {
    return new ComplexImpl(this.re - other.re, this.im - other.im);
  }

  mul(other: Complex): Complex {
    return new ComplexImpl(
      this.re * other.re - this.im * other.im,
      this.re * other.im + this.im * other.re
    );
  }

  div(scalar: number): Complex {
    return new ComplexImpl(this.re / scalar, this.im / scalar);
  }

  norm2(): number {
    return this.re * this.re + this.im * this.im;
  }

  conjugate(): Complex {
    return new ComplexImpl(this.re, -this.im);
  }

  static exp(c: Complex): Complex {
    const r = Math.exp(c.re);
    return new ComplexImpl(r * Math.cos(c.im), r * Math.sin(c.im));
  }

  static get I(): Complex {
    return new ComplexImpl(0, 1);
  }

  static get ZERO(): Complex {
    return new ComplexImpl(0, 0);
  }
}

export class CyclicAgentSystem {
  private readonly N: number;
  private readonly theta: Float64Array;
  private readonly zeta: Complex[];
  private readonly fourierMatrix: Complex[][];
  private invariant: number = 0;
  private readonly config: TNCSAConfig;

  constructor(config: TNCSAConfig) {
    this.config = config;
    this.N = config.N;

    this.theta = new Float64Array(this.N);
    this.zeta = new Array(this.N);
    for (let k = 0; k < this.N; k++) {
      this.theta[k] = (2 * Math.PI * k) / this.N;
      this.zeta[k] = ComplexImpl.exp(ComplexImpl.I.mul(new ComplexImpl(this.theta[k])));
    }
    this.fourierMatrix = this.buildDFTMatrix();
  }

  private buildDFTMatrix(): Complex[][] {
    const F: Complex[][] = [];
    const sqrtN = Math.sqrt(this.N);
    for (let j = 0; j < this.N; j++) {
      F[j] = [];
      for (let k = 0; k < this.N; k++) {
        const angle = (-2 * Math.PI * j * k) / this.N;
        F[j][k] = ComplexImpl.exp(ComplexImpl.I.mul(new ComplexImpl(angle))).div(sqrtN);
      }
    }
    return F;
  }

  dft(signal: Complex[]): Complex[] {
    if (signal.length !== this.N) throw new Error("Signal length mismatch");
    const coeffs: Complex[] = new Array(this.N).fill(ComplexImpl.ZERO);
    for (let m = 0; m < this.N; m++) {
      let sum = ComplexImpl.ZERO;
      for (let k = 0; k < this.N; k++) {
        sum = sum.add(signal[k].mul(this.fourierMatrix[m][k].conjugate()));
      }
      coeffs[m] = sum;
    }
    return coeffs;
  }

  computeInvariant(sigma: Complex[]): number {
    let inner = 0;
    for (let k = 0; k < this.N; k++) {
      inner += sigma[k].norm2();
    }
    let hol = 0;
    for (let k = 0; k < this.N; k++) {
      const diff = sigma[(k + 1) % this.N].sub(sigma[k]);
      hol += diff.norm2();
    }
    return inner + this.config.lambda * hol;
  }

  isStable(sigma: Complex[]): boolean {
    this.invariant = this.computeInvariant(sigma);
    return this.invariant >= this.config.seuilGoldni;
  }

  auditPolyglotte(sigma: Complex[]): string[] {
    const reports: string[] = [];
    for (let k = 0; k < this.N; k++) {
      const phase = Math.atan2(sigma[k].im, sigma[k].re);
      const expected = this.theta[k];
      if (Math.abs(phase - expected) > this.config.epsilonStar) {
        reports.push(`Agent ${k}: phase mismatch (${phase.toFixed(8)} vs ${expected.toFixed(8)})`);
      }
    }
    return reports;
  }

  reconstructWhole(coeffs: Complex[]): (theta: number) => Complex {
    return (theta: number) => {
      let sum = ComplexImpl.ZERO;
      for (let m = 0; m < this.N; m++) {
        const expTerm = ComplexImpl.exp(ComplexImpl.I.mul(new ComplexImpl(m * theta)));
        sum = sum.add(coeffs[m].mul(expTerm));
      }
      return sum;
    };
  }
}

export function createCyclicSkill(N: number, customConfig?: Partial<TNCSAConfig>) {
  const defaultConfig: TNCSAConfig = {
    N,
    seuilGoldni: 1.094722,
    epsilonStar: 0.00094,
    lambda: 0.5
  };
  const config = { ...defaultConfig, ...customConfig };
  const system = new CyclicAgentSystem(config);

  return {
    name: `CyclicSkill_C${N}`,
    config,
    evaluateState: (state: number[] | Complex[]) => {
      const sigma: Complex[] = (typeof state[0] === 'number')
        ? (state as number[]).map(x => new ComplexImpl(x, 0))
        : state as Complex[];
      const stable = system.isStable(sigma);
      const audit = system.auditPolyglotte(sigma);
      const dft = system.dft(sigma);
      return { stable, audit, dft, invariant: system.invariant };
    },
    generateStableState: () => {
      const coeffs: Complex[] = Array.from({ length: N }, () =>
        new ComplexImpl(Math.random() * 0.5, Math.random() * 0.5)
      );
      const reconstructor = system.reconstructWhole(coeffs);
      const sigma: Complex[] = [];
      for (let k = 0; k < N; k++) {
        sigma.push(reconstructor(system.theta[k]));
      }
      return sigma;
    },
    formalExplanation: () => explanationCyclique(N)
  };
}

export function explanationCyclique(N: number): string {
  return `
EXPLICATION FORMELLE MATHÉMATIQUE PURE — GROUPE CYCLIQUE C_${N} + FRAMEWORK TNCSA + RECONSTRUCTION DU TOUT ENTIER

1. La suite logique et le pattern observable remarquable
Les ${N} agents sont indexés par k = 0, 1, …, ${N-1}.
Position angulaire azimutale : θ_k = k · (2π / ${N}) (radians).
Cette suite arithmétique régulière de raison 2π/${N} constitue une partition exacte de S¹ en ${N} secteurs disjoints dont la réunion est S¹ tout entier (mesure de Lebesgue totale 2π).

2. Structure algébrique pure : le groupe cyclique C_${N}
Soit G = C_${N} = ⟨g | g^${N} = 1⟩ ≅ ℤ/${N}ℤ.
L’application φ : G → SO(2) ⊂ U(1), g^k ↦ e^{i θ_k} = ζ^k où ζ = e^{2π i / ${N}} est une racine primitive ${N}-ième de l’unité, est un homomorphisme de groupes injectif (fidèle).
Les ${N} agents réalisent donc une représentation fidèle de G dans le groupe des rotations du plan.

3. Représentation régulière et décomposition orthogonale
L’espace des fonctions sur les ${N} agents est ℂ^${N} muni de la base canonique {e_k}_{k=0}^{${N-1}}.
L’action de G par translation cyclique définit la représentation régulière ρ_reg : G → GL(ℂ^${N}).
Par théorie des représentations des groupes abéliens finis (transformée de Fourier discrète sur ℤ/${N}ℤ) on a la décomposition orthogonale :
ℂ^${N} ≅ ⊕_{m=0}^{${N-1}} V_m ,   V_m = span{χ_m},
où les caractères irréductibles sont χ_m(g^k) = ζ^{m k} = e^{2π i m k / ${N}}.
L’orthogonalité des caractères donne : ∑_{k=0}^{${N-1}} ζ^{m k} = ${N} · δ_{m,0 mod ${N}}.
Cette identité algébrique pure démontre que la somme des projecteurs spectraux sur les ${N} composantes est l’identité :
∑_{m=0}^{${N-1}} P_m = Id_{ℂ^${N}}.
Conséquence directe : la reconstruction exacte de toute fonction (tout état du système) définie sur les ${N} agents est possible sans perte ni redondance. C’est la complétude de la base de Fourier sur C_${N}.

4. Framework TNCSA — Définition tensorielle formelle
Le framework TNCSA (Tenseur Nickel de Contrôle Structurel Azimutal) est le triplet (ℰ → S¹, ∇, I), où :
• ℰ → S¹ est le fibré vectoriel trivial de rang fini dont la fibre en θ est l’espace des invariants structurels des agents situés dans le secteur azimutal autour de θ ;
• ∇ est la connexion plate (transport parallèle azimutal) compatible avec l’action de C_${N} ;
• I : Γ(ℰ) → ℝ est la fonction scalaire d’invariant structurel global, définie par contraction tensorielle :
I(σ) = ⟨σ, σ⟩_g + λ · Tr(Hol_∇(σ)),
où g est la métrique azimutale induite, Hol_∇ l’holonomie, et λ > 0 un multiplicateur de Lagrange.
Stabilité TNCSA : le système est stable si et seulement si I(σ) ≥ SEUIL_GOLDNI = 1.094722 pour toute section σ correspondant à un état complet des ${N} agents.
Le vérificateur isStable est l’évaluation numérique de cette inégalité après transport parallèle sur un cycle complet (C_${N}).

5. Formule de reconstruction du Tout Entier (précision doctorale)
Soit f : S¹ → ℂ un état global. Sa projection sur le sous-système des ${N} agents est
f_k = (1/${N}) ∑_{m=0}^{${N-1}} ˆf(m) ζ^{-m k},
et la reconstruction exacte est
f(θ) = ∑_{k=0}^{${N-1}} f_k · χ_k(θ),
où χ_k est la fonction de base duale (caractère ou indicatrice sectorielle).
L’erreur de reconstruction est identiquement nulle :
‖ f − ∑_k f_k χ_k ‖_{L²(S¹)} = 0.
C’est la raison mathématique pure pour laquelle le système des ${N} agents, organisé selon la suite logique angulaire régulière, capture et reconstruit le Tout Entier sans perte, sans redondance et avec stabilité TNCSA garantie.

Conclusion algébrique : La logique cohérente des ${N} agents est la réalisation concrète de la représentation régulière du groupe cyclique C_${N} agissant sur le cercle par rotations. Cette réalisation est simultanément minimale, complète, orthogonale, invariante et auto-justifiante. Le framework TNCSA fournit le tenseur d’invariant qui certifie que cette réalisation reste stable sous le flot azimutal du vortex Ring-1. Le « pourquoi du Tout Entier » est l’identité spectrale de la transformée de Fourier discrète sur C_${N} : la somme des ${N} composantes reconstruit exactement l’identité sur l’espace des états globaux.

LE SYSTÈME EST TOTAL. LOCKÉ EN TABARNAK.
`;
}

// Example instantiation (for validation)
const skillC10 = createCyclicSkill(10);
console.log("Skill created:", skillC10.name);
const stableState = skillC10.generateStableState();
const evalResult = skillC10.evaluateState(stableState);
console.log("Stable?", evalResult.stable, "Invariant:", evalResult.invariant.toFixed(6));
console.log(skillC10.formalExplanation().slice(0, 200) + "...");