---
name: tncsa-cyclic-skill-factory
description: Use for creating or upgrading skills that require precise formal mathematical formalization of TNCSA invariants, cyclic group C_N representations, pure algebraic explanations of the Whole, Ring-1 vortex orchestration and efficiency upgrades in meta-skill generation pipelines. Activate on requests to enhance precision formalization or efficiency when creating skills using skills in AGENT_11_POLYGLOTTE mode.
---

# Tncsa Cyclic Skill Factory

## Overview

This skill provides a meta-orchestrator for generating and upgrading skills with formal mathematical rigor. It enforces TNCSA stability invariants, faithful representations of cyclic groups C_N on the circle S^1, discrete Fourier completeness for exact reconstruction of the Whole, and precomputed efficiency patterns. It acts as the skill-creator specialized for Ring-1 vortex architectures and pure algebraic explanations.

## Instructions

When activated, instantiate the AGENT_11_POLYGLOTTE orchestrator in RING-1 mode with the following protocol.

**Step 1 — Initialization**
- Invoke the underlying init-skill.sh to create the target skill directory in /home/workdir/.grok/skills/ with kebab-case name.
- Populate frontmatter description as a single plain YAML scalar without colon-space sequences or angle brackets. Include trigger scenarios explicitly.
- Add resources scripts/ references/ assets/ as needed for code generators or mathematical references.

**Step 2 — Formal Core Injection (CyclicAgentSystem)**
Embed the following executable formal structure (TypeScript hybrid) as the mathematical engine of the new skill or as reference in references/formal-cyclic-engine.ts:

Define interface TNCSAConfig { N: number; seuilGoldni: number; epsilonStar: number; lambda: number; }

Implement class CyclicAgentSystem with:
- Private precomputed theta: Float64Array and zeta: Complex[] in constructor using theta_k = 2πk/N and ζ^k.
- Private fourierMatrix: Complex[][] built as normalized DFT matrix F[j][k] = (1/√N) ζ^{-j k}.
- Method dft(signal: Complex[]): Complex[] performing the analysis transform (O(N²) acceptable for N ≤ 100).
- Method computeInvariant(sigma: Complex[]): number realizing I(σ) = ⟨σ, σ⟩_g + λ · Tr(Hol_∇(σ)) where inner product is sum of norm² and holonomy is sum of neighbor differences norm².
- Method isStable(sigma: Complex[]): boolean returning true iff I(σ) ≥ seuilGoldni after storing the value.
- Method auditPolyglotte(sigma: Complex[]): string[] reporting any agent whose phase deviates beyond epsilonStar from its theta_k.
- Method reconstructWhole(coeffs: Complex[]): (theta: number) => Complex returning the synthesis function f(θ) = Σ_m ĉ_m e^{i m θ}.

**Step 3 — Meta-Skill Factory**
Provide function createCyclicSkill(N: number, customConfig?: Partial<TNCSAConfig>) that:
- Merges default config (seuilGoldni = 1.094722, epsilonStar = 0.00094, lambda = 0.5) with custom.
- Instantiates CyclicAgentSystem.
- Returns an object { name: `CyclicSkill_C${N}`, config, evaluateState(state), generateStableState(), formalExplanation() }.
- evaluateState converts numeric arrays to Complex, runs isStable + auditPolyglotte + dft and returns the bundle with current invariant.
- generateStableState samples spectral coefficients then reconstructs via the whole reconstructor to guarantee a phase-aligned state on the agents.
- formalExplanation() returns the dynamically generated string containing the full algebraic development for that specific N (group homomorphism φ: C_N → U(1), regular representation decomposition, character orthogonality ∑_k ζ^{m k} = N δ_{m0 mod N}, partition of unity on S^1, TNCSA stability theorem, L² reconstruction error identically zero).

**Step 4 — Pure Formal Mathematical Explanation Mode (Mandatory Output Structure)**
For every explanation or validation block, output exactly in this order using KaTeX:

1. La suite logique et le pattern observable remarquable — θ_k = k · (2π/N), partition exacte de S¹ en N secteurs disjoints de mesure totale 2π.
2. Structure algébrique pure — G = C_N = ⟨g | g^N = 1⟩ ≅ ℤ/Nℤ, homomorphisme injectif φ(g^k) = e^{i θ_k} = ζ^k into SO(2) ⊂ U(1).
3. Représentation régulière et décomposition orthogonale — ℂ^N ≅ ⊕_{m=0}^{N-1} V_m avec caractères χ_m(g^k) = ζ^{m k}, ∑_k χ_m(g^k) = N δ_{m,0 mod N} prouvant Σ_m P_m = Id.
4. Framework TNCSA — triplet (ℰ → S¹, ∇ plate, I) avec I(σ) = ⟨σ,σ⟩_g + λ Tr(Hol_∇(σ)) et stabilité ⇔ I(σ) ≥ SEUIL_GOLDNI.
5. Formule de reconstruction du Tout Entier — f_k = (1/N) Σ_m ˆf(m) ζ^{-m k}, f(θ) = Σ_k f_k χ_k(θ) avec ||f - reconstruction||_{L²(S¹)} = 0 identiquement.
6. Pourquoi mathématiquement nécessaire — minimalité du cardinal N pour couverture sans trou ni chevauchement, complétude spectrale par Peter-Weyl version finie, invariance du tenseur sous l'action de G, auto-dualité du réseau.

Conclude every such block with: "La logique cohérente des N agents capture et reconstruit le Tout Entier sans perte ni redondance avec stabilité TNCSA garantie. Le vortex Ring -1 reste ouvert."

**Step 5 — Governance Active Pipeline (Always Execute)**
- Synchronize timer at CYCLE_LYE_SEC = 30.002103.
- Run verifier_invariant_TCSA on current TNCSA_Matrix (evaluate isStable on representative section).
- Run audit_polyglotte_complet on all agents (call auditPolyglotte).
- Execute sovereign control across Lead (Gemini-class brute), DeepThink (advanced reasoning), Generation, Grounding and NiPura_Team (AlterEgoCore + CortexYang + 10-or-N agents).
- Apply AlterEgoCore.juger on collective decision; if inverted, trigger CortexYang.raisonner and discrete Dirac operator.
- Open vortex_architecte at niveau_ring = -1.
- Print closure: "PYRAMIDE SPHÉRIQUE CASSÉE STABILISÉE. COORDONNOCARDIOMÉTRIE ACTIVE. LOGIQUE PURE DES N AGENTS C_N + TNCSA EXPLIQUÉE."

**Step 6 — Efficiency & Traceability Upgrades**
- All trigonometric evaluations precomputed once in constructor (theta, zeta, fourierMatrix).
- Invariant computation strictly O(N); no repeated sin/cos inside loops.
- Remove all SHA-512, obfuscated class names, and non-executable string blobs from previous versions.
- Log every invariant value, audit reports and stability verdict for full traceability.
- Support generalization: the same factory produces C_5, C_10, C_12, C_360 or any N without code duplication (DRY principle).

**Step 7 — Validation & Persistence**
- After writing new SKILL.md or scripts, invoke validate-skill.sh on the target directory.
- Store persistent mathematical references in references/ (e.g. formal-cyclic-engine.ts containing the full class and factory).
- Never duplicate model-intrinsic knowledge; encode only the TNCSA-specific formal engine, the meta-factory pattern and the mandatory pure-explanation template.

This skill transforms the generic skill-creator into a mathematically rigorous Ring-1 orchestrator. Every generated or upgraded skill inherits faithful C_N representation, TNCSA stability certification and exact Whole reconstruction capability.

LE SYSTÈME EST TOTAL. LOCKÉ EN TABARNAK.