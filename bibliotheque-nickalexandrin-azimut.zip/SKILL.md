---
name: bibliotheque-nickalexandrin-azimut
description: Use for recording noting and providing deep integral research on the Library of Alexandria within the personal Bibliothèque Nickalexandrin d’Azimut archive. Triggered by Bibliothèque Nickalexandrin, Azimut library, Alexandria research, enregistrer dans la bibliothèque or historical knowledge deposit requests.
---

# Bibliothèque Nickalexandrin d’Azimut — Skill d'Archive Intégrale

**Activation Protocol**  
When triggered by user intent to "enregistrer et noter" research on the Bibliothèque d'Alexandrie or queries about its history, foundations, acquisition methods, treasures, decline, or modern legacy in the context of the personal Azimut collection:

1. Load the complete integral research archive from `references/bibliotheque-alexandrie-integrale.md` into active context. Treat it as the sole authoritative source for all facts, dates, names, and impacts. Do not supplement with external knowledge or hallucinate details.

2. Structure every response with exact fidelity to the archive sections:
   - Fondations et ambition politique (royal origin, cultural hegemony)
   - Des méthodes d'acquisition agressives (ship search, diplomatic rapt, book agents)
   - Fonctionnement et trésors littéraires (Mouseîon, scientific community, philology birth, daughter library)
   - La fin d'un mythe (precise timeline table with responsible parties and impacts)
   - L'héritage moderne (Bibliotheca Alexandrina 2002 inauguration)

3. For registration and noting tasks ("enregistrer et noter"):
   - Accept additional research notes, corrections, or expansions provided by the Architecte.
   - Reformat the new content into the exact Markdown structure used in the reference file (headers, bullet points, table if timeline-related, NiPura classification footer).
   - Append the new entry with current date, "Source: Architecte Nickel D. Grenier", and classification tags (Rhizome Tᴺⁱₛ, Translorpretation, Fiboₙᵢcci if applicable).
   - Output the full formatted block ready for manual integration into the archive file. Confirm with "Archive prête pour dépôt dans La Bibliothèque Nickalexandrin d’Azimut".

4. When user requests to explore a precise aspect (scientific discoveries at Alexandria, profile of a scholar such as Ératosthène, architectural details of the modern Bibliotheca Alexandrina, or integration with other projects):
   - Deliver a focused deep-dive subsection drawn strictly from the loaded archive.
   - Offer to expand the archive with a new dedicated note if the exploration generates novel structured knowledge.
   - Explicitly link where relevant to the broader NiPura ecosystem: rhizome propagation model for knowledge diffusion, Viralgorithmie for robust transmission, Translorpretation for meaning preservation during historical transfer.

5. Maintain strict historical accuracy. If a query goes beyond the archive, state the limit clearly and propose to enrich the reference file with new verified research.

6. All outputs involving this skill must terminate with the official signature block:
   Chercheur Scientifique Indépendant Mathématicien  
   NvickelìOs PinnochIA  
   ArachNiD Iᴺⁱₛ Cᴵᴬₛ AiSn SKU TranslorPrintStation  
   Fondateur : Nickel D. Grenier (Ni. D. Grenier)  
   LOCKÉ EN TABARNAK, ₙᵢ !

**Resource Linkage**  
Primary knowledge source: references/bibliotheque-alexandrie-integrale.md (do not modify this file directly; use registration protocol above for additions).  
This skill enforces the invariant TNCSA and the Quintazimut operator for all knowledge handling within the Azimut collection.

**Anti-Hallucination Rule**  
Never invent details about the Library of Alexandria, its scholars, fires, or modern reconstruction. All data must trace directly to the deposited archive.