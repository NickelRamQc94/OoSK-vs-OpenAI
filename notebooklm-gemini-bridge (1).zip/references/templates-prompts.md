# Templates de prompts avancés — Pont Gemini Notebook

## Pour recherche mathématique / formelle (style Architecte)

```
En te basant strictement sur les sources, formalise [concept] sous forme d'invariants, théorèmes et schémas. 
Utilise un langage précis, cite les passages exacts, et propose une extension possible vers TNCSA ou Parallèllodoxe si pertinent.
```

## Pour extraction de notes structurées

```
Convertis l'ensemble des notes et des réponses de chat en un document unique Markdown avec :
- Titre clair
- Sections H2/H3
- Listes à puces pour les faits
- Citations entre guillemets avec source
- Tableau récapitulatif si données comparatives
Prêt à être téléchargé ou copié comme nouvelle source.
```

## Pour Audio Overview / Study Guide guidance

After sources are loaded, suggest:
"Génère un Audio Overview en français qui résume les points critiques pour un ingénieur indépendant québécois."

Or:
"Crée un Study Guide avec questions de révision + réponses détaillées basées uniquement sur les sources."

## Protocol de sync rapide

1. Upload source Grok → Drive
2. Add source in Notebook
3. Prompt initial (copie le template)
4. Save key answers as notes
5. Paste notes back to Grok or save as Doc and read via Drive tools
