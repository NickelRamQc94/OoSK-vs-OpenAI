#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════
  PONT RÉSEAU — Gemini Notebook (ex-NotebookLM)  ↔  Google Drive
  Auteur     : Nickel D. Grenier + Loup Junior (Grok)
  Version    : 1.0.0-Ni  |  2026-08-01
  Licence    : Usage personnel souverain — Architecte Nickel
═══════════════════════════════════════════════════════════════════════════

Réalité technique (août 2026) :
  • Gemini Notebook (consommateur) → AUCUNE API publique pour chat/notes.
  • Le seul pont OFFICIEL et stable = Google Drive comme intermédiaire.
  • Les fichiers Drive (Docs/PDF/MD) ajoutés comme sources se re-synchronisent
    automatiquement dans le Notebook (quelques minutes).
  • Direction inverse (notes/chat → Drive) = export manuel ou unofficial.

Modes du script :
  1. DRIVE   — pont officiel 100 % Google Drive API (recommandé)
  2. HYBRID  — Drive + notebooklm-py (unofficial, optionnel, à tes risques)
  3. SETUP   — crée l’arborescence de dossiers dans ton Drive

Prérequis :
  pip install -r requirements.txt
  # OAuth Google : place credentials.json (Google Cloud Console → Drive API)
  # ou utilise un token déjà autorisé (token.json)

Usage rapide :
  python pont_notebooklm_drive.py setup
  python pont_notebooklm_drive.py push ./mon_recherche.md --title "Source-Grok-01"
  python pont_notebooklm_drive.py list
  python pont_notebooklm_drive.py pull
  python pont_notebooklm_drive.py status
"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# ─── Config par défaut ───────────────────────────────────────────────────────
DEFAULT_ROOT_FOLDER_NAME = "Pont-NotebookLM-Ni"
SUBFOLDERS = {
    "sources": "01-Sources",
    "exports": "02-Exports-Notes",
    "chat": "03-Chat-Logs",
    "prompts": "04-Prompts-Bridge",
}
CONFIG_FILE = Path.home() / ".pont_notebooklm" / "config.json"
SCOPES = [
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/drive.file",
]

# ─── Couleurs terminal (optionnel) ───────────────────────────────────────────
class C:
    OK = "\033[92m"
    WARN = "\033[93m"
    ERR = "\033[91m"
    INFO = "\033[94m"
    BOLD = "\033[1m"
    END = "\033[0m"


def log(msg: str, level: str = "info") -> None:
    prefix = {
        "ok": f"{C.OK}[OK]{C.END}",
        "warn": f"{C.WARN}[!]{C.END}",
        "err": f"{C.ERR}[ERR]{C.END}",
        "info": f"{C.INFO}[·]{C.END}",
    }.get(level, "[·]")
    print(f"{prefix} {msg}")


# ─── Google Drive Auth ───────────────────────────────────────────────────────
def get_drive_service():
    """Construit le service Drive v3 via OAuth2 (credentials.json / token.json)."""
    try:
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build
    except ImportError as e:
        log(
            "Dépendances manquantes. Installe :\n"
            "  pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib",
            "err",
        )
        raise SystemExit(1) from e

    creds = None
    token_path = Path.home() / ".pont_notebooklm" / "token.json"
    creds_path = Path.home() / ".pont_notebooklm" / "credentials.json"

    # Fallback : dossier courant
    if not creds_path.exists():
        alt = Path("credentials.json")
        if alt.exists():
            creds_path = alt

    token_path.parent.mkdir(parents=True, exist_ok=True)

    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not creds_path.exists():
                log(
                    "Fichier credentials.json introuvable.\n"
                    "  1. Va sur https://console.cloud.google.com/\n"
                    "  2. Active l’API Google Drive\n"
                    "  3. Crée des identifiants OAuth (Desktop app)\n"
                    "  4. Télécharge JSON → place-le dans ~/.pont_notebooklm/credentials.json",
                    "err",
                )
                raise SystemExit(1)
            flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
            creds = flow.run_local_server(port=0)
        token_path.write_text(creds.to_json(), encoding="utf-8")
        log(f"Token sauvegardé → {token_path}", "ok")

    return build("drive", "v3", credentials=creds)


# ─── Config locale ───────────────────────────────────────────────────────────
def load_config() -> dict[str, Any]:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    return {}


def save_config(cfg: dict[str, Any]) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    log(f"Config → {CONFIG_FILE}", "ok")


# ─── Helpers Drive ───────────────────────────────────────────────────────────
def find_folder(service, name: str, parent_id: Optional[str] = None) -> Optional[str]:
    q = (
        f"name = '{name}' and mimeType = 'application/vnd.google-apps.folder' "
        f"and trashed = false"
    )
    if parent_id:
        q += f" and '{parent_id}' in parents"
    res = (
        service.files()
        .list(q=q, spaces="drive", fields="files(id, name)", pageSize=5)
        .execute()
    )
    files = res.get("files", [])
    return files[0]["id"] if files else None


def create_folder(service, name: str, parent_id: Optional[str] = None) -> str:
    meta: dict[str, Any] = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    if parent_id:
        meta["parents"] = [parent_id]
    folder = service.files().create(body=meta, fields="id, name, webViewLink").execute()
    log(f"Dossier créé : {name}  ({folder['id']})", "ok")
    return folder["id"]


def ensure_folder(service, name: str, parent_id: Optional[str] = None) -> str:
    existing = find_folder(service, name, parent_id)
    if existing:
        log(f"Dossier existant : {name}", "info")
        return existing
    return create_folder(service, name, parent_id)


def upload_file(
    service,
    local_path: Path,
    parent_id: str,
    title: Optional[str] = None,
    as_google_doc: bool = False,
) -> dict[str, Any]:
    from googleapiclient.http import MediaFileUpload

    name = title or local_path.name
    mime, _ = mimetypes.guess_type(str(local_path))
    mime = mime or "application/octet-stream"

    body: dict[str, Any] = {"name": name, "parents": [parent_id]}
    media = MediaFileUpload(str(local_path), mimetype=mime, resumable=True)

    if as_google_doc and local_path.suffix.lower() in {".txt", ".md", ".markdown"}:
        body["mimeType"] = "application/vnd.google-apps.document"
        media = MediaFileUpload(str(local_path), mimetype="text/plain", resumable=True)

    f = (
        service.files()
        .create(body=body, media_body=media, fields="id, name, webViewLink, mimeType")
        .execute()
    )
    log(f"Upload OK → {f['name']}  |  {f.get('webViewLink', '')}", "ok")
    return f


def upload_text_as_doc(
    service, content: str, title: str, parent_id: str
) -> dict[str, Any]:
    """Crée un Google Doc à partir de texte brut."""
    from googleapiclient.http import MediaInMemoryUpload

    media = MediaInMemoryUpload(content.encode("utf-8"), mimetype="text/plain", resumable=True)
    body = {
        "name": title,
        "parents": [parent_id],
        "mimeType": "application/vnd.google-apps.document",
    }
    f = (
        service.files()
        .create(body=body, media_body=media, fields="id, name, webViewLink")
        .execute()
    )
    log(f"Doc créé → {f['name']}  |  {f.get('webViewLink', '')}", "ok")
    return f


def list_folder_files(service, folder_id: str, page_size: int = 50) -> list[dict]:
    res = (
        service.files()
        .list(
            q=f"'{folder_id}' in parents and trashed = false",
            spaces="drive",
            fields="files(id, name, mimeType, modifiedTime, webViewLink, size)",
            pageSize=page_size,
            orderBy="modifiedTime desc",
        )
        .execute()
    )
    return res.get("files", [])


# ─── Commandes CLI ───────────────────────────────────────────────────────────
def cmd_setup(args: argparse.Namespace) -> None:
    """Crée l’arborescence complète du pont dans Google Drive."""
    service = get_drive_service()
    root_id = ensure_folder(service, DEFAULT_ROOT_FOLDER_NAME)
    ids = {"root": root_id}
    for key, name in SUBFOLDERS.items():
        ids[key] = ensure_folder(service, name, parent_id=root_id)

    cfg = {
        "root_folder_id": root_id,
        "folders": ids,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "root_name": DEFAULT_ROOT_FOLDER_NAME,
    }
    save_config(cfg)

    # Fichier README dans le dossier prompts
    readme = f"""# Pont NotebookLM ↔ Drive — {DEFAULT_ROOT_FOLDER_NAME}

Créé le {datetime.now().strftime('%Y-%m-%d %H:%M')}

## Structure
- **01-Sources**      → fichiers à ajouter comme sources dans Gemini Notebook
- **02-Exports-Notes** → notes / exports collés depuis le Notebook
- **03-Chat-Logs**    → journaux de bavardage (copier-coller)
- **04-Prompts-Bridge** → prompts prêts à coller dans le chat Notebook

## Workflow officiel
1. Push une source ici (script ou upload manuel) dans 01-Sources
2. Ouvre https://notebooklm.google.com → ton notebook
3. Add source → Google Drive → sélectionne le(s) fichier(s) de 01-Sources
4. Les Docs/Sheets se re-sync auto quand tu les modifies dans Drive
5. Pour ramener des notes : Save to note dans le Notebook → copie →
   colle dans un Doc dans 02-Exports-Notes (ou utilise `python pont_notebooklm_drive.py pull`)

Aucun API public consumer n’existe pour le chat live (août 2026).
Drive reste le seul pont stable et officiel.
"""
    upload_text_as_doc(service, readme, "README-Pont-Ni", ids["prompts"])
    log("Setup terminé. Arborescence prête.", "ok")
    print(f"\n{C.BOLD}Ouvre le dossier :{C.END}")
    print(f"  https://drive.google.com/drive/folders/{root_id}")


def cmd_push(args: argparse.Namespace) -> None:
    """Upload un fichier local vers 01-Sources (prêt pour NotebookLM)."""
    cfg = load_config()
    if not cfg.get("folders", {}).get("sources"):
        log("Config manquante. Lance d’abord : python pont_notebooklm_drive.py setup", "err")
        raise SystemExit(1)

    path = Path(args.file)
    if not path.exists():
        log(f"Fichier introuvable : {path}", "err")
        raise SystemExit(1)

    service = get_drive_service()
    parent = cfg["folders"]["sources"]
    title = args.title or path.name
    as_doc = args.as_doc or path.suffix.lower() in {".txt", ".md", ".markdown"}

    result = upload_file(service, path, parent, title=title, as_google_doc=as_doc)

    print(f"\n{C.BOLD}Prochaine étape dans Gemini Notebook :{C.END}")
    print("  1. Ouvre https://notebooklm.google.com")
    print("  2. Add source → Google Drive")
    print(f"  3. Cherche : {result['name']}")
    print(f"  4. Lien direct : {result.get('webViewLink', '—')}")


def cmd_push_text(args: argparse.Namespace) -> None:
    """Crée un Google Doc source à partir de texte (stdin ou --text)."""
    cfg = load_config()
    if not cfg.get("folders", {}).get("sources"):
        log("Config manquante. Lance setup d’abord.", "err")
        raise SystemExit(1)

    if args.text:
        content = args.text
    elif not sys.stdin.isatty():
        content = sys.stdin.read()
    else:
        log("Fournis --text ou pipe du contenu via stdin", "err")
        raise SystemExit(1)

    title = args.title or f"Source-Grok-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    service = get_drive_service()
    result = upload_text_as_doc(service, content, title, cfg["folders"]["sources"])
    print(f"\nLien : {result.get('webViewLink', '—')}")


def cmd_list(args: argparse.Namespace) -> None:
    """Liste les fichiers du pont (sources / exports / all)."""
    cfg = load_config()
    if not cfg.get("folders"):
        log("Config manquante. Lance setup d’abord.", "err")
        raise SystemExit(1)

    service = get_drive_service()
    targets = {
        "sources": "01-Sources",
        "exports": "02-Exports-Notes",
        "chat": "03-Chat-Logs",
        "prompts": "04-Prompts-Bridge",
    }
    which = args.which or "all"

    for key, label in targets.items():
        if which != "all" and which != key:
            continue
        fid = cfg["folders"].get(key)
        if not fid:
            continue
        files = list_folder_files(service, fid)
        print(f"\n{C.BOLD}── {label} ({len(files)}) ──{C.END}")
        if not files:
            print("  (vide)")
            continue
        for f in files:
            mt = f.get("modifiedTime", "")[:19].replace("T", " ")
            print(f"  • {f['name']}")
            print(f"    {mt}  |  {f.get('webViewLink', '')}")


def cmd_pull(args: argparse.Namespace) -> None:
    """
    Aide au pull : liste les exports récents + génère un template de note
    à coller dans 02-Exports-Notes.
    """
    cfg = load_config()
    if not cfg.get("folders", {}).get("exports"):
        log("Config manquante. Lance setup d’abord.", "err")
        raise SystemExit(1)

    service = get_drive_service()
    files = list_folder_files(service, cfg["folders"]["exports"])
    print(f"\n{C.BOLD}Exports récents (02-Exports-Notes) :{C.END}")
    if not files:
        print("  (aucun export encore)")
    else:
        for f in files[:15]:
            print(f"  • {f['name']}  →  {f.get('webViewLink', '')}")

    if args.create_template:
        template = f"""# Note exportée — Gemini Notebook
Date : {datetime.now().strftime('%Y-%m-%d %H:%M')}
Notebook : [nom du notebook]
Sources utilisées : [liste]

## Contenu (collé depuis Save to note)

[ COLLE ICI LA RÉPONSE / NOTE DU NOTEBOOK ]

## Citations
- 

## Questions de suivi pour le prochain tour
1. 
2. 
3. 
"""
        title = args.title or f"Export-Note-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        result = upload_text_as_doc(
            service, template, title, cfg["folders"]["exports"]
        )
        print(f"\nTemplate créé → {result.get('webViewLink', '')}")
        print("Ouvre-le, colle ta note Notebook, sauvegarde.")


def cmd_prompt(args: argparse.Namespace) -> None:
    """Génère / upload un prompt prêt à coller dans le chat Gemini Notebook."""
    cfg = load_config()
    prompts = {
        "ground": (
            "Tu es mon expert de recherche personnel basé UNIQUEMENT sur les sources "
            "de ce notebook.\n"
            "Analyse en profondeur le sujet demandé.\n"
            "Structure ta réponse avec :\n"
            "1. Synthèse exécutive\n"
            "2. Points clés avec citations exactes\n"
            "3. Liens entre concepts\n"
            "4. Questions ouvertes pour approfondir\n"
            "Cite toujours les sources."
        ),
        "extract": (
            "À partir des notes et sources, extrais toutes les informations liées "
            "au thème demandé.\n"
            "Produis un tableau structuré + une liste de citations verbatim.\n"
            "Puis génère 3 questions de suivi ultra-précises."
        ),
        "note": (
            "Transforme les notes sélectionnées en un document source autonome, "
            "clair, avec titres, listes et citations préservées. "
            "Prêt à être réutilisé comme source."
        ),
    }

    kind = args.kind or "ground"
    text = prompts.get(kind, prompts["ground"])
    if args.topic:
        text = f"Sujet / thème : {args.topic}\n\n{text}"

    print(f"\n{C.BOLD}── Prompt ({kind}) — copie dans le chat Notebook ──{C.END}\n")
    print(text)
    print()

    if args.upload and cfg.get("folders", {}).get("prompts"):
        service = get_drive_service()
        title = f"Prompt-{kind}-{datetime.now().strftime('%Y%m%d-%H%M')}"
        upload_text_as_doc(service, text, title, cfg["folders"]["prompts"])


def cmd_status(args: argparse.Namespace) -> None:
    """État du pont + check réseau basique."""
    cfg = load_config()
    print(f"\n{C.BOLD}═══ STATUT PONT NotebookLM ↔ Drive ═══{C.END}\n")
    if not cfg:
        log("Aucune config. Lance : python pont_notebooklm_drive.py setup", "warn")
        return

    print(f"  Root folder : {cfg.get('root_name')}  ({cfg.get('root_folder_id')})")
    print(f"  Créé le     : {cfg.get('created_at', '?')}")
    print(f"  Config      : {CONFIG_FILE}")
    print()

    # Test auth + comptage
    try:
        service = get_drive_service()
        for key, label in SUBFOLDERS.items():
            fid = cfg.get("folders", {}).get(key)
            if not fid:
                print(f"  {label}: (non configuré)")
                continue
            files = list_folder_files(service, fid)
            print(f"  {label}: {len(files)} fichier(s)")
        log("Connexion Drive OK", "ok")
    except Exception as e:
        log(f"Erreur Drive : {e}", "err")

    # notebooklm-py optionnel
    try:
        import notebooklm  # noqa: F401

        log("notebooklm-py détecté (mode HYBRID possible)", "ok")
    except ImportError:
        log("notebooklm-py non installé (mode DRIVE seul — recommandé)", "info")

    print(f"\n  Dossier Drive :")
    print(f"  https://drive.google.com/drive/folders/{cfg.get('root_folder_id', '')}")
    print(f"\n  Gemini Notebook : https://notebooklm.google.com")
    print()


def cmd_hybrid_info(args: argparse.Namespace) -> None:
    """Info sur le mode unofficial notebooklm-py."""
    print(
        f"""
{C.BOLD}Mode HYBRID (unofficial) — notebooklm-py{C.END}

Google n’offre PAS d’API publique consumer pour Gemini Notebook.
La lib communautaire notebooklm-py reverse-engineere l’API web via cookies/Playwright.

Installer (à tes risques — zone grise ToS) :
  pip install "notebooklm-py[browser]"
  notebooklm login          # ouvre le navigateur, récupère les cookies
  notebooklm auth check

Exemples CLI notebooklm-py :
  notebooklm create "Mon Notebook Ni"
  notebooklm source add ./fichier.pdf
  notebooklm source add "https://..."
  notebooklm ask "Résume les points clés"
  notebooklm generate audio --wait

Python async :
  from notebooklm import NotebookLMClient
  async with NotebookLMClient.from_storage() as client:
      nbs = await client.notebooks.list()
      ...

Ce script reste centré sur le pont Drive OFFICIEL.
Le mode hybrid est optionnel et non garanti (casse possible à chaque update Google).
"""
    )


# ─── Main ────────────────────────────────────────────────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Pont réseau Gemini Notebook (NotebookLM) ↔ Google Drive",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Auteur : Nickel D. Grenier + Loup Junior  |  ❤️94",
    )
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("setup", help="Crée l’arborescence Drive du pont")
    sub.add_parser("status", help="État du pont + test connexion")

    sp = sub.add_parser("push", help="Upload un fichier local → 01-Sources")
    sp.add_argument("file", help="Chemin du fichier local")
    sp.add_argument("--title", help="Nom dans Drive")
    sp.add_argument(
        "--as-doc",
        action="store_true",
        help="Convertir en Google Doc (idéal pour .md/.txt)",
    )

    st = sub.add_parser("push-text", help="Crée un Doc source depuis texte/stdin")
    st.add_argument("--text", help="Contenu texte")
    st.add_argument("--title", help="Titre du Doc")

    sl = sub.add_parser("list", help="Liste les fichiers du pont")
    sl.add_argument(
        "--which",
        choices=["all", "sources", "exports", "chat", "prompts"],
        default="all",
    )

    pl = sub.add_parser("pull", help="Liste exports + template de note")
    pl.add_argument(
        "--create-template",
        action="store_true",
        help="Crée un Doc template dans 02-Exports-Notes",
    )
    pl.add_argument("--title", help="Titre du template")

    pr = sub.add_parser("prompt", help="Génère un prompt prêt pour le chat Notebook")
    pr.add_argument(
        "--kind",
        choices=["ground", "extract", "note"],
        default="ground",
    )
    pr.add_argument("--topic", help="Sujet à injecter dans le prompt")
    pr.add_argument(
        "--upload",
        action="store_true",
        help="Sauve aussi le prompt dans 04-Prompts-Bridge",
    )

    sub.add_parser("hybrid-info", help="Info mode unofficial notebooklm-py")
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    dispatch = {
        "setup": cmd_setup,
        "status": cmd_status,
        "push": cmd_push,
        "push-text": cmd_push_text,
        "list": cmd_list,
        "pull": cmd_pull,
        "prompt": cmd_prompt,
        "hybrid-info": cmd_hybrid_info,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
