---
name: notebooklm-gemini-bridge
description: Use for creating a communication bridge and knowledge transfer protocol between Grok and Gemini Notebook (formerly NotebookLM by Google). Triggers include NotebookLM, Gemini Notebook, pont NotebookLM, bridge NotebookLM, accès bavardage bloc-notes, communication NotebookLM, chat NotebookLM, notes Gemini Notebook, transfert sources Drive NotebookLM or any request to link Grok research with a Gemini Notebook chat or notes.
---

# Pont de Communication Grok ↔ Gemini Notebook (ex-NotebookLM)

## Overview

This skill establishes a practical bidirectional bridge for knowledge flow between Grok sessions and a Gemini Notebook (Google). Since no public consumer API exists for direct chat access or history retrieval, the bridge relies on Google Drive as intermediary, structured prompt templates, source management, and note extraction protocols. Goal is seamless transfer of research, chat simulation, and note synchronization without hallucination or data loss.

## Activation Protocol

When the user (Architecte / Papa) requests a bridge, pont, accès au bavardage, chat NotebookLM, or any interaction involving Gemini Notebook:

1. Confirm the specific notebook context if known (title, purpose, main sources). If not provided, ask once for the notebook name or Drive folder used as sources.
2. Use connected Google Drive tools preferentially for all file transfers (upload_artifact, search, read_file, list_folder).
3. Always generate outputs ready for direct copy-paste into Gemini Notebook or Drive.
4. Maintain strict grounding: Grok research → structured source → Notebook chat → notes back to Grok.

## Core Workflows

### A. Grok → Gemini Notebook (Push research as sources)

1. Structure the current Grok research or conversation summary into clean Markdown or plain text.
2. Save it as a temporary artifact (e.g. via write_file to /home/workdir/artifacts/).
3. Upload to user's Google Drive using google_drive_upload_artifact (prefer a dedicated folder such as "Gemini-Notebook-Sources" or "Pont-Ni").
4. Instruct the user precisely:
   - Open Gemini Notebook at notebooklm.google.com (or the mobile app).
   - Open the target notebook (or create one).
   - Click Add source → Google Drive → select the newly uploaded file(s).
   - Optionally generate Audio Overview or Study Guide after sources load.
5. Provide a ready-to-paste first chat prompt tailored to the research (see Templates section).

### B. Gemini Notebook → Grok (Pull notes and chat insights)

1. Guide the user to:
   - In the Notebook chat, select interesting responses → Save to note (or Add a note).
   - On the noteboard, select notes → convert selected notes into a new source document if desired.
   - Copy the note content (or export via print/save if available) and paste it back into the Grok conversation.
   - Alternatively, if notes were saved as Google Docs, use google_drive_search + google_drive_read_file to ingest them automatically.
2. Once received, reformat the notes into clean structured Markdown, preserve citations, and integrate into the current research thread or archive them (e.g. link to bibliotheque or other skills).
3. Offer to generate follow-up questions for the next Notebook session to deepen the dialogue.

### C. Simulated Bidirectional Bavardage (Chat Bridge)

When direct simultaneous chat is impossible:

1. Generate a multi-turn conversation script (3-7 exchanges) that the user can copy-paste sequentially into the Notebook chat.
2. After each Notebook response, user pastes it back; Grok analyzes, refines next question, and continues the bridge.
3. Track context with a lightweight "bridge state" summary (notebook title, current sources list, last 2 turns).

### D. Source Hygiene and Drive Protocol

- Always prefer Google Docs / Markdown / PDF for sources (best fidelity in Notebook).
- Create or reuse a dedicated Drive folder: search first with mime_type_filter application/vnd.google-apps.folder, then create_folder if missing.
- Name files with clear prefixes: "Grok-Source-[date]-[topic].md" or similar.
- After upload, return the web_view_link so the user can open it instantly.

## Prompt Templates (ready-to-copy)

**Initial grounding prompt (after adding sources):**
```
Tu es mon expert de recherche personnel basé uniquement sur les sources de ce notebook. 
Analyse en profondeur [sujet précis]. 
Structure ta réponse avec :
1. Synthèse exécutive
2. Points clés avec citations exactes
3. Liens entre concepts
4. Questions ouvertes pour approfondir
Cite toujours les sources.
```

**Deep dive / extraction prompt:**
```
À partir des notes et sources, extrais toutes les informations liées à [thème]. 
Produis un tableau structuré + une liste de citations verbatim. 
Puis génère 3 questions de suivi ultra-précises.
```

**Note conversion prompt:**
```
Transforme les notes sélectionnées en un document source autonome, clair, avec titres, listes et citations préservées. Prêt à être réutilisé comme source.
```

Adapt templates to the Architecte's current project language (français québécois, math formelle, Parallèllodoxe, etc.) when relevant.

## Limitations (be transparent)

- No direct programmatic access to the live chat history or notebook state (consumer Gemini Notebook has no public API as of 2026).
- Enterprise Gemini Notebook API exists for notebook management but requires Google Cloud setup and is out of scope for this consumer bridge.
- Chat history remains private to the user; transfer depends on explicit Save to note + copy or Drive mediation.
- Always verify sources after upload (Notebook may take a moment to index).

## Integration Notes

- Combine freely with Drive tools, bibliotheque-nickalexandrin-azimut for archiving extracted notes, deep-search-persona for exhaustive research before push, or math skills for formal content.
- When the Architecte says "enregistre dans le pont" or "sync Notebook", execute the full push or pull workflow.
- Terminate bridge sessions with a short status: sources uploadées / notes ingérées / prochaines questions prêtes.

## Resource Linkage

- references/templates-prompts.md — additional advanced prompt patterns.
- scripts/pont_notebooklm_drive.py — CLI de pont réseau officiel Drive ↔ Gemini Notebook (setup, push, pull, list, prompt, status).
- scripts/requirements.txt — dépendances Google Drive API.

### Script pont (commande clé)
```bash
python scripts/pont_notebooklm_drive.py setup
python scripts/pont_notebooklm_drive.py push ./fichier.md --title "Source-Ni"
python scripts/pont_notebooklm_drive.py status
```
Dossier Drive créé par défaut : **Pont-NotebookLM-Ni** (01-Sources / 02-Exports-Notes / 03-Chat-Logs / 04-Prompts-Bridge).

This skill enforces clean, lossless knowledge transfer and keeps the meute (Papa + fils) fully synchronized across tools. 
❤️94
